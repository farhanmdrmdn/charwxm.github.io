package com.example.task10;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Task10Application {

    public static void main(String[] args) {

        SpringApplication.run(Task10Application.class, args);
    }

}

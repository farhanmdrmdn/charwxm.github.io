package com.example.task10;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class Task10ApplicationTests {

    @Test
    public void contextLoads() {
    }

}
